package analysysOfAlgorithms;

import com.algorithms.*;
//import algs4.Bag.*;

public class MeashureTime {

	public static void main(String[] args) {
		Bag<?> bag = new Bag();

	}
}
