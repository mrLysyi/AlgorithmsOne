package _week1;

import com.algorithms.QuickUnionUF;

public class Percolation {
	private QuickUnionUF massive;
	private int N;
	private int id[]; // indicate current state of PERCOLATION node, 0-blocked;
						// 1-open;2-Full.

	public Percolation(int N) {
		if (N <= 1)
			throw new IndexOutOfBoundsException("N must be > 1");
		this.N = N;
		// QuickUnionUF masiveJ;
		massive = new QuickUnionUF(N * N);
		id = new int[N * N];
		for (int i = 1; i < N * N; i++) {
			id[i] = 0;
		}
	} // create N-by-N grid, with all sites blocked (zero 0 )

	public void open(int i, int j) {
		if (i <= 0 || i > N)
			throw new IndexOutOfBoundsException("row index i out of bounds");
		if (j <= 0 || j > N)
			throw new IndexOutOfBoundsException("row index j out of bounds");
		int el = element(i, j); // element in QuickUNION line
		i--;
		j--;
		if (id[el] == 0)
			id[el] = 1; // set current item as OPEN (1)
						// connect elements, if they are open or FILL
		if (i == 0) { // RIGHT
			if (j == 0) { // UPPER left CORNER
				if (!(id[el + 1] == 0)) // RIGHT
					massive.union(el, el + 1);
				if (!(id[el + N] == 0)) // DOWN
					massive.union(el, el + N);
			} else if (j == N - 1) { // DOWN left CORNER
				if (!(id[el + 1] == 0)) // RIGHT
					massive.union(el, el + 1);
				if (!(id[el - N] == 0)) // UPPER
					massive.union(el, el - N);
			} else { // LEFT side
				if (!(id[el + 1] == 0)) // RIGHT
					massive.union(el, el + 1);
				if (!(id[el - N] == 0)) // UPPER
					massive.union(el, el - N);
				if (!(id[el + N] == 0)) // DOWN
					massive.union(el, el + N);
			}

		} else if (i == N - 1) { // LEFT
			if (j == 0) { // UPPER right CORNER
				if (!(id[el - 1] == 0)) // LEFT
					massive.union(el, el - 1);
				if (!(id[el + N] == 0)) // DOWN
					massive.union(el, el + N);

			} else if (j == N - 1) { // DOWN right CORNER
				if (!(id[el - 1] == 0)) // LEFT
					massive.union(el, el - 1);
				if (!(id[el - N] == 0)) // UPPER
					massive.union(el, el - N);

			} else { // RIGHT side
				if (!(id[el - 1] == 0)) // LEFT
					massive.union(el, el - 1);
				if (!(id[el - N] == 0)) // UPPER
					massive.union(el, el - N);
				if (!(id[el + N] == 0)) // DOWN
					massive.union(el, el + N);
			}

		} else if (i > 0 && i < N) {
			if (j == 0) { // UPPER side
				if (!(id[el - 1] == 0)) // LEFT
					massive.union(el, el - 1);
				if (!(id[el + 1] == 0)) // RIGHT
					massive.union(el, el + 1);
				if (!(id[el + N] == 0)) // DOWN
					massive.union(el, el + N);

			} else if (j == N - 1) { // DOWN side
				if (!(id[el - 1] == 0)) // LEFT
					massive.union(el, el - 1);
				if (!(id[el + 1] == 0)) // RIGHT
					massive.union(el, el + 1);
				if (!(id[el - N] == 0)) // UPPER
					massive.union(el, el - N);

			} else if (j > 0 && j < N) { // in the middle
				if (!(id[el - 1] == 0)) // LEFT
					massive.union(el, el - 1);
				if (!(id[el + 1] == 0)) // RIGHT
					massive.union(el, el + 1);
				if (!(id[el - N] == 0)) // UPPER
					massive.union(el, el - N);
				if (!(id[el + N] == 0)) // DOWN
					massive.union(el, el + N);
			} else
				System.out.println("wrong OPEN!!!!");
		}
	} // open site (row i, column j) if it is not already

	public boolean isOpen(int i, int j) {
		int el = element(i, j);
		if ((id[el] == 1))
			return true;
		else
			return false;
	} // is site (row i, column j) open?

	public boolean isFull(int i, int j) {
		int el = element(i, j);
		if (id[el] == 2)
			return true;
		if (i == 1 && id[el] != 0) {
			id[el] = 2;
			return true;
		}
		for (int k = 0; k < N * N; k = k + N) {
			if (massive.connected(k, el)) {
				if (id[el] == 1) {
					id[el] = 2;
					return true;
				}
			}
		}
		return false;
	} // is site (row i, column j) full?

	public boolean percolates() {
		int n = N;
		for (int k = n * n - 1; k > 0; k = k - n) {
			if (id[k] == 2)
				return true;
		}
		return false;
	} // does the system percolate?

	private int element(int i, int j) {
		i--;
		j--;
		return (i + j * (N));
	}

	public static void main(String[] args) {
		Percolation per = new Percolation(10);
		int n = per.N;
	
		for (int k = n * n - 1; k > 0; k = k - n) {

			System.out.println(k);
		}
		System.out.println(14 % 7);
	}// test client, optional
}
